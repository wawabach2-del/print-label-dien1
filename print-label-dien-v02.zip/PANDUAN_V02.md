# PRINT LABEL DIEN v0.2 — Panduan

> **Status jujur:** kode ini **belum dijalankan di HP maupun printer**. Yang sudah diuji hanya logika murni (bitmap → perintah TSPL/ESC/POS) lewat `npm test`. Build APK, Bluetooth, dan cetak ke AL-100BLP baru terbukti setelah Anda mencoba. Jika ada error, kirim tangkapan layarnya.

## Fitur
- Impor banyak PDF/gambar sekaligus + terima dari menu Bagikan (Shopee, galeri, WhatsApp, dll.).
- PDF multi-halaman → tiap halaman jadi satu pekerjaan. Tombol **Bagi** memecah satu halaman jadi 2 atau 4 label (untuk PDF Shopee yang memuat beberapa resi per halaman).
- **Crop manual** (seret jari) + **Auto** (buang tepi putih).
- Pratinjau = bitmap hitam-putih yang sama persis dengan yang dikirim.
- Ukuran label dapat diatur (bawaan 100×100 mm), jumlah salinan per label, urutan (↑↓).
- **Cetak semua** / **cetak terpilih** berurutan, jeda, lanjut, batalkan. Satu printer satu pekerjaan; tombol terkunci agar tidak terkirim dobel.
- Status: Menunggu · Mencetak · Berhasil dikirim · Gagal · Perlu diperiksa.
- **Hapus file yang sudah tercetak tanpa uninstal**: tombol “Hapus semua yang sudah tercetak”, atau aktifkan hapus otomatis di Pengaturan. Hanya salinan di aplikasi yang dihapus; file asli Shopee/galeri tidak disentuh; riwayat tetap.
- Bluetooth LE (Android + iPhone) dan Bluetooth Classic (Android). Protokol TSPL dan ESC/POS.

## Cara membuat APK (tanpa akun Expo)
Build berjalan di server GitHub (gratis dengan batas kuota). Dari HP:

1. Di Chrome buka repo `print-label-dien` di github.com → **Add file → Upload files** → unggah `print-label-dien-v02.zip` → **Commit changes**.
2. Buka codespace Anda. Di terminal ketik satu per satu:
   ```
   cd /workspaces/print-label-dien
   git pull
   rm -rf tahap2
   unzip -o print-label-dien-v02.zip
   git add -A
   git commit -m "versi 0.2"
   git push
   ```
3. Di github.com buka repo → tab **Actions** → **Build APK Android** → **Run workflow** → **Run workflow**.
4. Tunggu ±15–30 menit sampai centang hijau. Jika merah, buka run-nya, salin/screenshot bagian yang gagal dan kirim ke saya.
5. Buka tab **Releases** (halaman utama repo, sisi kanan) → rilis terbaru → ketuk **PrintLabelDien.apk** untuk mengunduh → pasang (izinkan "pasang dari sumber ini").
6. Setelah selesai, hapus codespace agar kuota tidak terpakai (github.com/codespaces).

## Menguji (centang satu per satu, dan laporkan hasilnya)
1. Tab **Printer** → Cari printer Bluetooth → apakah **AL-100BLP** muncul? Jika muncul dua kali (BLE dan Classic), tambahkan keduanya.
2. Atur 100×100 mm → **Cetak halaman uji**. Yang diharapkan: kotak, garis silang, teks “PRINT LABEL DIEN”, dan barcode.
   - Tidak ada reaksi → coba protokol **ESC/POS**, atau profil BLE ↔ Classic.
   - Label keluar tapi kosong/geser → tekan tombol FEED di printer untuk kalibrasi label; ubah **Gap**.
3. Impor 1 gambar → **Pratinjau** → **Cetak label ini**. Jika hitam-putih terbalik, aktifkan **Balik hitam/putih**.
4. Impor PDF resi Shopee → coba **Bagi** / **Crop** → cetak 5 label sekaligus (**Cetak semua**).
5. Bagikan PDF dari Shopee/WhatsApp ke PRINT LABEL DIEN → masuk antrean?
6. Setelah tercetak → **Hapus semua yang sudah tercetak** → file hilang dari aplikasi, file asli tetap ada.
7. Matikan printer saat mencetak → antrean berhenti, sisanya tetap **Menunggu**.
8. Cek barcode/QR hasil cetak bisa dipindai (resolusi PDF bisa terbatas; lihat catatan di bawah).

## Yang belum pasti
- **Protokol AL-100BLP** belum dikonfirmasi (TSPL, ESC/POS, atau lainnya). Halaman uji menentukannya.
- **Arti bit TSPL** (hitam=0 atau 1) bergantung firmware; tombol “Balik hitam/putih” menjadi penyesuaiannya.
- **Ketajaman PDF:** halaman PDF dirender oleh pustaka bawaan dengan resolusi yang belum saya ketahui. Jika barcode kabur, saya akan ganti ke modul render beresolusi tinggi.
- **BLE pada iPhone** hanya jalan jika AL-100BLP memang menyediakan BLE. Jika hanya Classic, iPhone tidak bisa mencetak ke printer ini (batasan iOS).
- **iPhone** juga butuh akun Apple Developer (±US$99/tahun) dan build terpisah; belum disiapkan di paket ini. Kode sudah dibuat lintas-platform.
- Crop saat ini dengan menggambar ulang kotak (belum ada gagang geser sudut).
