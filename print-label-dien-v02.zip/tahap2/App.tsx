import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, SafeAreaView, Text, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useShareIntent } from 'expo-share-intent';
import { useApp } from './src/useApp';
import { QueueScreen } from './src/screens/QueueScreen';
import { PrintersScreen } from './src/screens/PrintersScreen';
import { HistoryScreen, SettingsScreen } from './src/screens/MiscScreens';
import { C } from './src/ui';

const TABS = ['Antrean', 'Printer', 'Riwayat', 'Pengaturan'] as const;
type Tab = (typeof TABS)[number];

export default function App() {
  const app = useApp();
  const [tab, setTab] = useState<Tab>('Antrean');
  const { hasShareIntent, shareIntent, resetShareIntent } = useShareIntent();

  // File dari menu Bagikan aplikasi lain (Shopee, galeri, WhatsApp, dll.)
  useEffect(() => {
    if (!app.ready || !hasShareIntent || !shareIntent?.files?.length) return;
    setTab('Antrean');
    app
      .importFiles(shareIntent.files.map((f: any) => ({ uri: f.path, name: f.fileName ?? 'file', mime: f.mimeType ?? undefined })))
      .then((r) => r.added && Alert.alert('Masuk antrean', `${r.added} file (${r.jobs} halaman) dari aplikasi lain.`))
      .finally(() => resetShareIntent());
  }, [app.ready, hasShareIntent, shareIntent]); // eslint-disable-line

  if (!app.ready) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="dark" />
      <View style={{ flex: 1 }}>
        {tab === 'Antrean' && <QueueScreen app={app} />}
        {tab === 'Printer' && <PrintersScreen app={app} />}
        {tab === 'Riwayat' && <HistoryScreen app={app} />}
        {tab === 'Pengaturan' && <SettingsScreen app={app} />}
      </View>
      <View style={{ flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderColor: C.line }}>
        {TABS.map((t) => (
          <Pressable key={t} style={{ flex: 1, paddingVertical: 14, alignItems: 'center' }} onPress={() => setTab(t)}>
            <Text style={{ fontWeight: '700', color: tab === t ? C.primary : C.sub }}>{t}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}
