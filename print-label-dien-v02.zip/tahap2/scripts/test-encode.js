// Uji logika murni. Jalankan: npm test  (mengompilasi src/core dengan tsc dulu)
const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const out = path.join(require('os').tmpdir(), 'pld-core-test');
fs.rmSync(out, { recursive: true, force: true });
execSync(
  `npx tsc src/core/*.ts --outDir ${out} --module commonjs --target es2019 --skipLibCheck --ignoreConfig`,
  { cwd: path.join(__dirname, '..'), stdio: 'inherit' },
);
const bits = require(path.join(out, 'bits.js'));
const proto = require(path.join(out, 'protocols.js'));
const { defaultPrinter } = require(path.join(out, 'types.js'));

let fail = 0;
function ok(cond, msg) {
  console.log((cond ? 'LULUS  ' : 'GAGAL  ') + msg);
  if (!cond) fail++;
}

// base64
const sample = new Uint8Array([0, 1, 2, 3, 250, 251, 252, 253, 254]);
for (let n = 0; n <= sample.length; n++) {
  const s = sample.slice(0, n);
  const back = bits.fromBase64(bits.toBase64(s));
  ok(Buffer.from(back).equals(Buffer.from(s)), `base64 bolak-balik n=${n}`);
}
ok(bits.toBase64(Buffer.from('Man')) === 'TWFu', 'base64 cocok dengan Buffer');

// ukuran 100x100 mm @203dpi
ok(bits.mmToDots(100, 203) === 799, '100 mm = 799 titik @203dpi');

// layout fit/fill
let l = bits.layoutInBox(400, 600, 800, 800, 'fit');
ok(l.w === 533 && l.h === 800, `fit 400x600 -> ${l.w}x${l.h}`);
l = bits.layoutInBox(400, 600, 800, 800, 'fill');
ok(l.w === 800 && l.h === 1200, `fill 400x600 -> ${l.w}x${l.h}`);

// packBits: piksel hitam pertama dan terakhir pada baris 10 titik
const w = 10, h = 2;
const mono = new Uint8Array(w * h).fill(255);
mono[0] = 0; // kiri atas hitam
mono[9] = 0; // kanan atas hitam
let p = bits.packBits(mono, w, h, true);
ok(p.widthBytes === 2, 'lebar 10 titik = 2 byte');
ok(p.data[0] === 0x80 && p.data[1] === 0x40, `ESC/POS bit1=hitam: ${p.data[0].toString(16)} ${p.data[1].toString(16)}`);
ok(p.data[2] === 0 && p.data[3] === 0, 'baris putih = 0 pada ESC/POS');
p = bits.packBits(mono, w, h, false);
ok(p.data[0] === 0x7f, `TSPL bit0=hitam: ${p.data[0].toString(16)}`);
ok(p.data[1] === 0xbf, `TSPL byte-2 (sisa padding=putih=1): ${p.data[1].toString(16)}`);

// threshold & dither
const g = new Uint8Array([10, 200, 129, 128]);
const b1 = bits.binarize(g, 4, 1, 170, false);
ok(b1[0] === 0 && b1[1] === 255 && b1[2] === 0, 'threshold 170');
const dither = bits.binarize(new Uint8Array(100).fill(128), 10, 10, 0, true);
const black = dither.filter((v) => v === 0).length;
ok(black > 30 && black < 70, `dithering abu-abu 50% -> ${black}/100 hitam`);

// kanvas + contentBox
const rgba = new Uint8Array(4 * 4 * 4);
for (let i = 0; i < 16; i++) { rgba[i*4]=0; rgba[i*4+1]=0; rgba[i*4+2]=0; rgba[i*4+3]=255; }
const canvas = bits.rgbaToGrayCanvas(rgba, 4, 4, 10, 10);
ok(canvas[0] === 255 && canvas[5 * 10 + 5] === 0, 'gambar di tengah kanvas putih');
const box = bits.contentBox(canvas, 10, 10, 235, 0);
ok(box && Math.abs(box.x - 0.3) < 1e-9 && Math.abs(box.w - 0.4) < 1e-9, 'contentBox menemukan kotak 4x4 di tengah');

// TSPL
const prof = defaultPrinter({ id: 'a', name: 'Algoo', transport: 'ble', address: 'x' });
const W = 800, H = 800;
const mono2 = new Uint8Array(W * H).fill(255);
const pk = bits.packBits(mono2, W, H, false);
const tspl = proto.tsplLabel(pk.data, pk.widthBytes, H, prof, 2);
const text = Buffer.from(tspl).toString('latin1');
ok(text.startsWith('SIZE 100 mm,100 mm\r\nGAP 3 mm,0 mm'), 'header TSPL');
ok(text.includes('BITMAP 0,0,100,800,0,'), 'perintah BITMAP lebar 100 byte x 800 baris');
ok(text.endsWith('\r\nPRINT 1,2\r\n'), 'PRINT 1,2 (2 salinan)');
const hdrLen = text.indexOf('BITMAP 0,0,100,800,0,') + 'BITMAP 0,0,100,800,0,'.length;
ok(tspl.length === hdrLen + 100 * 800 + '\r\nPRINT 1,2\r\n'.length, `panjang total TSPL ${tspl.length} byte`);

// ESC/POS
const esc = proto.escposLabel(bits.packBits(mono2, W, H, true).data, 100, H, 1);
ok(esc[2] === 0x1d && esc[3] === 0x76 && esc[4] === 0x30, 'header GS v 0');
ok(esc[6] === 100 && esc[7] === 0 && esc[8] === (800 & 255) && esc[9] === 800 >> 8, 'xL xH yL yH benar');

// pratinjau ASCII dari label uji kecil (cek orientasi tidak terbalik)
const tw = 32, th = 8;
const t = new Uint8Array(tw * th).fill(255);
for (let x = 0; x < 16; x++) t[0 * tw + x] = 0; // garis atas kiri
const tp = bits.packBits(t, tw, th, true);
const row0 = Array.from(tp.data.slice(0, 4)).map((v) => v.toString(2).padStart(8, '0')).join('');
ok(row0 === '11111111111111110000000000000000', `baris atas: ${row0}`);

console.log(fail ? `\n${fail} uji GAGAL` : '\nSemua uji lulus');
process.exit(fail ? 1 : 0);
