import { Platform, StatusBar, StyleSheet } from 'react-native';
import { JobStatus } from './core/types';

export const C = {
  bg: '#f6f7f9',
  card: '#ffffff',
  text: '#111827',
  sub: '#6b7280',
  line: '#e5e7eb',
  primary: '#2563eb',
  danger: '#dc2626',
  ok: '#16a34a',
  warn: '#d97706',
};

export const STATUS_LABEL: Record<JobStatus, string> = {
  MENUNGGU: 'Menunggu',
  MENCETAK: 'Mencetak…',
  TERKIRIM: 'Berhasil dikirim',
  GAGAL: 'Gagal',
  PERLU_PERIKSA: 'Perlu diperiksa',
};
export const STATUS_COLOR: Record<JobStatus, string> = {
  MENUNGGU: C.sub,
  MENCETAK: C.primary,
  TERKIRIM: C.ok,
  GAGAL: C.danger,
  PERLU_PERIKSA: C.warn,
};

export const topPad = Platform.OS === 'android' ? (StatusBar.currentHeight ?? 28) : 8;

export const s = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg, paddingTop: topPad },
  title: { fontSize: 22, fontWeight: '800', color: C.text, marginHorizontal: 16 },
  sub: { color: C.sub, marginHorizontal: 16, marginBottom: 8 },
  card: { backgroundColor: C.card, marginHorizontal: 12, marginVertical: 4, padding: 12, borderRadius: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  h2: { fontWeight: '700', color: C.text, fontSize: 15 },
  meta: { color: C.sub, fontSize: 12, marginTop: 2 },
  btn: { paddingVertical: 13, paddingHorizontal: 14, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },
  btnSm: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 10, backgroundColor: '#eef2ff' },
  btnSmTxt: { color: C.primary, fontWeight: '700', fontSize: 13 },
  primary: { backgroundColor: C.primary },
  danger: { backgroundColor: C.danger },
  gray: { backgroundColor: '#374151' },
  off: { opacity: 0.35 },
  input: { borderWidth: 1, borderColor: C.line, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, minWidth: 64, color: C.text, backgroundColor: '#fff' },
  label: { color: C.sub, fontSize: 12, marginTop: 8, marginBottom: 2 },
  empty: { color: C.sub, textAlign: 'center', margin: 32, lineHeight: 22 },
  bar: { flexDirection: 'row', gap: 8, padding: 12, paddingBottom: 14, backgroundColor: '#fff', borderTopWidth: 1, borderColor: C.line },
});
