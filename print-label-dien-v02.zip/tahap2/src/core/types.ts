// Tipe data bersama. Tanpa impor React Native agar bisa diuji di Node.

export type Crop = { x: number; y: number; w: number; h: number }; // 0..1 dari halaman

export const FULL_CROP: Crop = { x: 0, y: 0, w: 1, h: 1 };

export type JobStatus =
  | 'MENUNGGU'
  | 'MENCETAK'
  | 'TERKIRIM'
  | 'GAGAL'
  | 'PERLU_PERIKSA';

export type Item = {
  id: string;
  name: string;
  uri: string; // salinan terkelola di folder aplikasi
  mime: string;
  size: number;
  pages: number;
  addedAt: number;
};

export type Job = {
  id: string;
  itemId: string;
  page: number; // 0-based
  crop: Crop;
  copies: number;
  status: JobStatus;
  error?: string;
};

export type Protocol = 'tspl' | 'escpos';
export type TransportKind = 'ble' | 'classic';

export type PrinterProfile = {
  id: string;
  name: string;
  transport: TransportKind;
  address: string; // BLE: id perangkat; Classic: alamat MAC
  protocol: Protocol;
  widthMm: number; // ukuran label
  heightMm: number;
  dpi: number; // 203 -> 8 titik/mm
  density: number; // 0..15 (TSPL)
  speed: number; // 1..6 (TSPL)
  gapMm: number; // celah antar label (TSPL)
  marginMm: number;
  invert: boolean; // balik bit BITMAP TSPL jika hasil cetak terbalik hitam/putih
  serviceUUID?: string; // BLE, diisi otomatis setelah berhasil
  charUUID?: string;
};

export type Settings = {
  autoDelete: boolean; // hapus salinan setelah semua halamannya TERKIRIM
  dither: boolean; // false = threshold tajam (disarankan untuk barcode/QR)
  threshold: number; // 0..255
  fitMode: 'fit' | 'fill';
};

export type HistoryRow = {
  id: string;
  name: string;
  page: number;
  printerName: string;
  copies: number;
  status: JobStatus;
  at: number;
};

export type AppState = {
  items: Item[];
  jobs: Job[];
  printers: PrinterProfile[];
  activePrinterId?: string;
  history: HistoryRow[];
  settings: Settings;
};

export const DEFAULT_SETTINGS: Settings = {
  autoDelete: false,
  dither: false,
  threshold: 170,
  fitMode: 'fit',
};

export function defaultPrinter(
  p: Partial<PrinterProfile> & Pick<PrinterProfile, 'id' | 'name' | 'transport' | 'address'>,
): PrinterProfile {
  return {
    protocol: 'tspl',
    widthMm: 100,
    heightMm: 100,
    dpi: 203,
    density: 8,
    speed: 4,
    gapMm: 3,
    marginMm: 2,
    invert: false,
    ...p,
  };
}
