import type { PrinterProfile } from './types';
import { ascii, concat } from './bits';

// ---------- TSPL (printer label) ----------
// Catatan: arti bit BITMAP (0 = hitam atau 1 = hitam) harus dipastikan lewat uji
// pada AL-100BLP. Gunakan profil.invert untuk membaliknya.
export function tsplLabel(
  data: Uint8Array,
  widthBytes: number,
  heightDots: number,
  p: PrinterProfile,
  copies: number,
): Uint8Array {
  const head =
    `SIZE ${p.widthMm} mm,${p.heightMm} mm\r\n` +
    `GAP ${p.gapMm} mm,0 mm\r\n` +
    `DIRECTION 0\r\n` +
    `DENSITY ${p.density}\r\n` +
    `SPEED ${p.speed}\r\n` +
    `CLS\r\n` +
    `BITMAP 0,0,${widthBytes},${heightDots},0,`;
  const tail = `\r\nPRINT 1,${Math.max(1, copies)}\r\n`;
  return concat(ascii(head), data, ascii(tail));
}

// Halaman uji TSPL tanpa gambar: kotak, garis silang, teks, dan barcode.
export function tsplTestPage(p: PrinterProfile): Uint8Array {
  const w = Math.round((p.widthMm * p.dpi) / 25.4);
  const h = Math.round((p.heightMm * p.dpi) / 25.4);
  const cmd =
    `SIZE ${p.widthMm} mm,${p.heightMm} mm\r\n` +
    `GAP ${p.gapMm} mm,0 mm\r\n` +
    `DIRECTION 0\r\n` +
    `DENSITY ${p.density}\r\n` +
    `SPEED ${p.speed}\r\n` +
    `CLS\r\n` +
    `BOX 4,4,${w - 4},${h - 4},4\r\n` +
    `BAR ${Math.round(w / 2)},4,2,${h - 8}\r\n` +
    `BAR 4,${Math.round(h / 2)},${w - 8},2\r\n` +
    `TEXT 30,30,"3",0,2,2,"PRINT LABEL DIEN"\r\n` +
    `TEXT 30,110,"3",0,1,1,"${p.widthMm}x${p.heightMm} mm TSPL"\r\n` +
    `BARCODE 30,${Math.round(h / 2) + 30},"128",90,1,0,2,2,"DIEN12345"\r\n` +
    `PRINT 1,1\r\n`;
  return ascii(cmd);
}

// ---------- ESC/POS (raster GS v 0) ----------
export function escposLabel(
  data: Uint8Array,
  widthBytes: number,
  heightDots: number,
  copies: number,
): Uint8Array {
  const one = concat(
    new Uint8Array([0x1b, 0x40]), // reset
    new Uint8Array([
      0x1d, 0x76, 0x30, 0x00,
      widthBytes & 0xff,
      (widthBytes >> 8) & 0xff,
      heightDots & 0xff,
      (heightDots >> 8) & 0xff,
    ]),
    data,
    new Uint8Array([0x1b, 0x64, 0x02]), // feed 2 baris
  );
  const parts: Uint8Array[] = [];
  for (let i = 0; i < Math.max(1, copies); i++) parts.push(one);
  return concat(...parts);
}

export function escposTestPage(p: PrinterProfile): Uint8Array {
  return concat(
    new Uint8Array([0x1b, 0x40]),
    ascii('PRINT LABEL DIEN\n'),
    ascii(`${p.widthMm}x${p.heightMm} mm ESC/POS\n`),
    ascii('ABCDEFGHIJKLMNOPQRSTUVWXYZ\n0123456789\n'),
    new Uint8Array([0x1b, 0x64, 0x03]),
  );
}
