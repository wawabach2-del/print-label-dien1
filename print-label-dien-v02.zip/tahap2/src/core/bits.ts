// Pemrosesan bitmap murni (tanpa React Native): RGBA -> hitam-putih 1 bit.

const B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

export function toBase64(bytes: Uint8Array): string {
  let out = '';
  const n = bytes.length;
  for (let i = 0; i < n; i += 3) {
    const a = bytes[i];
    const b = i + 1 < n ? bytes[i + 1] : 0;
    const c = i + 2 < n ? bytes[i + 2] : 0;
    out += B64[a >> 2] + B64[((a & 3) << 4) | (b >> 4)];
    out += i + 1 < n ? B64[((b & 15) << 2) | (c >> 6)] : '=';
    out += i + 2 < n ? B64[c & 63] : '=';
  }
  return out;
}

export function fromBase64(s: string): Uint8Array {
  const clean = s.replace(/[^A-Za-z0-9+/]/g, '');
  const len = Math.floor((clean.length * 3) / 4);
  const out = new Uint8Array(len);
  let o = 0;
  for (let i = 0; i < clean.length; i += 4) {
    const e1 = B64.indexOf(clean[i]);
    const e2 = B64.indexOf(clean[i + 1]);
    const e3 = i + 2 < clean.length ? B64.indexOf(clean[i + 2]) : -1;
    const e4 = i + 3 < clean.length ? B64.indexOf(clean[i + 3]) : -1;
    if (o < len) out[o++] = (e1 << 2) | (e2 >> 4);
    if (e3 >= 0 && o < len) out[o++] = ((e2 & 15) << 4) | (e3 >> 2);
    if (e4 >= 0 && o < len) out[o++] = ((e3 & 3) << 6) | e4;
  }
  return out;
}

export function concat(...parts: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const p of parts) total += p.length;
  const out = new Uint8Array(total);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}

export function ascii(s: string): Uint8Array {
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 0xff;
  return out;
}

export function mmToDots(mm: number, dpi: number): number {
  return Math.round((mm * dpi) / 25.4);
}

// Hitung ukuran gambar di dalam kotak label.
// 'fit'  : seluruh isi terlihat, rasio dipertahankan (tidak terpotong).
// 'fill' : kotak penuh, sisi berlebih terpotong di tengah.
export function layoutInBox(
  srcW: number,
  srcH: number,
  boxW: number,
  boxH: number,
  mode: 'fit' | 'fill',
) {
  const sx = boxW / srcW;
  const sy = boxH / srcH;
  const s = mode === 'fit' ? Math.min(sx, sy) : Math.max(sx, sy);
  const w = Math.max(1, Math.round(srcW * s));
  const h = Math.max(1, Math.round(srcH * s));
  return { w, h, scale: s };
}

// RGBA (tinggi x lebar) -> abu-abu 0..255 di atas kanvas putih berukuran canvasW x canvasH.
// Gambar ditempatkan di tengah; transparan dianggap putih.
export function rgbaToGrayCanvas(
  rgba: Uint8Array,
  w: number,
  h: number,
  canvasW: number,
  canvasH: number,
): Uint8Array {
  const gray = new Uint8Array(canvasW * canvasH).fill(255);
  const ox = Math.floor((canvasW - w) / 2);
  const oy = Math.floor((canvasH - h) / 2);
  for (let y = 0; y < h; y++) {
    const cy = y + oy;
    if (cy < 0 || cy >= canvasH) continue;
    for (let x = 0; x < w; x++) {
      const cx = x + ox;
      if (cx < 0 || cx >= canvasW) continue;
      const i = (y * w + x) * 4;
      const a = rgba[i + 3] / 255;
      const lum = 0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2];
      gray[cy * canvasW + cx] = Math.round(lum * a + 255 * (1 - a));
    }
  }
  return gray;
}

// Abu-abu -> 0 (hitam) / 255 (putih). Threshold tajam atau Floyd-Steinberg.
export function binarize(
  gray: Uint8Array,
  w: number,
  h: number,
  threshold: number,
  dither: boolean,
): Uint8Array {
  const out = new Uint8Array(w * h);
  if (!dither) {
    for (let i = 0; i < out.length; i++) out[i] = gray[i] < threshold ? 0 : 255;
    return out;
  }
  const buf = new Float32Array(gray.length);
  for (let i = 0; i < gray.length; i++) buf[i] = gray[i];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = y * w + x;
      const old = buf[i];
      const nv = old < 128 ? 0 : 255;
      out[i] = nv;
      const err = old - nv;
      if (x + 1 < w) buf[i + 1] += (err * 7) / 16;
      if (y + 1 < h) {
        if (x > 0) buf[i + w - 1] += (err * 3) / 16;
        buf[i + w] += (err * 5) / 16;
        if (x + 1 < w) buf[i + w + 1] += (err * 1) / 16;
      }
    }
  }
  return out;
}

// Kemas 0/255 menjadi 1 bit per titik, MSB dulu. Lebar dibulatkan ke kelipatan 8.
// blackIsOne=true  -> bit 1 = hitam (ESC/POS)
// blackIsOne=false -> bit 0 = hitam (BITMAP TSPL standar)
export function packBits(
  mono: Uint8Array,
  w: number,
  h: number,
  blackIsOne: boolean,
): { data: Uint8Array; widthBytes: number } {
  const widthBytes = Math.ceil(w / 8);
  const data = new Uint8Array(widthBytes * h);
  for (let y = 0; y < h; y++) {
    for (let bx = 0; bx < widthBytes; bx++) {
      let byte = 0;
      for (let k = 0; k < 8; k++) {
        const x = bx * 8 + k;
        const black = x < w && mono[y * w + x] === 0;
        const bit = blackIsOne ? (black ? 1 : 0) : black ? 0 : 1;
        byte |= bit << (7 - k);
      }
      data[y * widthBytes + bx] = byte;
    }
  }
  return { data, widthBytes };
}

// Cari kotak isi (bukan putih) untuk "Potong otomatis". Hasil 0..1; null jika kosong.
export function contentBox(
  gray: Uint8Array,
  w: number,
  h: number,
  whiteLevel = 235,
  padPx = 2,
): { x: number; y: number; w: number; h: number } | null {
  let minX = w,
    minY = h,
    maxX = -1,
    maxY = -1;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (gray[y * w + x] < whiteLevel) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
    }
  }
  if (maxX < 0) return null;
  minX = Math.max(0, minX - padPx);
  minY = Math.max(0, minY - padPx);
  maxX = Math.min(w - 1, maxX + padPx);
  maxY = Math.min(h - 1, maxY + padPx);
  return {
    x: minX / w,
    y: minY / h,
    w: (maxX - minX + 1) / w,
    h: (maxY - minY + 1) / h,
  };
}
