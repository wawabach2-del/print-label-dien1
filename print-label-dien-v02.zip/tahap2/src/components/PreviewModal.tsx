import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Image, Modal, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { Item, Job, PrinterProfile, Settings } from '../core/types';
import { monoPreviewUri, renderMono } from '../render';
import { s, topPad } from '../ui';

type Props = {
  visible: boolean;
  item: Item | null;
  job: Job | null;
  printer?: PrinterProfile;
  settings: Settings;
  onClose: () => void;
  onPrint: () => void;
};

// Pratinjau = bitmap hitam-putih yang sama persis dengan yang dikirim ke printer.
export function PreviewModal({ visible, item, job, printer, settings, onClose, onPrint }: Props) {
  const win = useWindowDimensions();
  const [uri, setUri] = useState<string | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!visible || !item || !job || !printer) return;
    setUri(null);
    setErr('');
    renderMono(item, job, printer, settings)
      .then((r) => setUri(monoPreviewUri(r)))
      .catch((e) => setErr(String(e?.message ?? e)));
  }, [visible, item, job, printer, settings]);

  const side = Math.min(win.width - 24, win.height - 280);
  const ratio = printer ? printer.widthMm / printer.heightMm : 1;

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#111', paddingTop: topPad }}>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 18, margin: 12 }}>
          Pratinjau {printer ? `${printer.widthMm}×${printer.heightMm} mm` : ''}
        </Text>
        {!printer && <Text style={{ color: '#fca5a5', margin: 12 }}>Pilih printer aktif dulu di tab Printer.</Text>}
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          {err ? (
            <Text style={{ color: '#fca5a5', margin: 16 }}>{err}</Text>
          ) : !uri ? (
            <ActivityIndicator color="#fff" size="large" />
          ) : (
            <Image source={{ uri }} style={{ width: side * Math.min(1, ratio), height: side / Math.max(1, ratio), backgroundColor: '#fff' }} resizeMode="contain" />
          )}
        </View>
        <View style={{ flexDirection: 'row', gap: 8, padding: 12, paddingBottom: 24 }}>
          <Pressable style={[s.btn, { flex: 1, backgroundColor: '#4b5563' }]} onPress={onClose}>
            <Text style={s.btnTxt}>Tutup</Text>
          </Pressable>
          <Pressable style={[s.btn, s.primary, { flex: 2 }, !uri && s.off]} disabled={!uri} onPress={onPrint}>
            <Text style={s.btnTxt}>Cetak label ini</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
