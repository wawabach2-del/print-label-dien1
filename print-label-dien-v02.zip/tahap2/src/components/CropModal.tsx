import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Image, Modal, PanResponder, Pressable, Text, View, useWindowDimensions } from 'react-native';
import { Crop, FULL_CROP, Item } from '../core/types';
import { autoCrop, getPageImage, PageImage } from '../render';
import { C, s, topPad } from '../ui';

type Props = {
  visible: boolean;
  item: Item | null;
  page: number;
  initial: Crop;
  onClose: () => void;
  onSave: (c: Crop) => void;
};

const clamp = (v: number) => Math.min(1, Math.max(0, v));

// Crop manual: seret jari di atas gambar untuk menggambar kotak potong.
export function CropModal({ visible, item, page, initial, onClose, onSave }: Props) {
  const win = useWindowDimensions();
  const [img, setImg] = useState<PageImage | null>(null);
  const [crop, setCrop] = useState<Crop>(initial);
  const [working, setWorking] = useState(false);

  useEffect(() => {
    if (!visible || !item) return;
    setCrop(initial);
    setImg(null);
    getPageImage(item, page).then(setImg).catch(() => setImg(null));
  }, [visible, item, page]); // eslint-disable-line

  const box = useMemo(() => {
    if (!img) return { w: 100, h: 100 };
    const maxW = win.width - 24;
    const maxH = win.height - 260;
    const k = Math.min(maxW / img.width, maxH / img.height);
    return { w: Math.round(img.width * k), h: Math.round(img.height * k) };
  }, [img, win.width, win.height]);

  const boxRef = useRef(box);
  boxRef.current = box;
  const start = useRef({ x: 0, y: 0 });

  const pan = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (e) => {
          const b = boxRef.current;
          start.current = { x: clamp(e.nativeEvent.locationX / b.w), y: clamp(e.nativeEvent.locationY / b.h) };
        },
        onPanResponderMove: (e) => {
          const b = boxRef.current;
          const x = clamp(e.nativeEvent.locationX / b.w);
          const y = clamp(e.nativeEvent.locationY / b.h);
          const x0 = Math.min(start.current.x, x);
          const y0 = Math.min(start.current.y, y);
          setCrop({ x: x0, y: y0, w: Math.abs(x - start.current.x), h: Math.abs(y - start.current.y) });
        },
      }),
    [],
  );

  const doAuto = async () => {
    if (!item) return;
    setWorking(true);
    try {
      const c = await autoCrop(item, page);
      if (c) setCrop(c);
    } finally {
      setWorking(false);
    }
  };

  const tooSmall = crop.w < 0.03 || crop.h < 0.03;

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={{ flex: 1, backgroundColor: '#111', paddingTop: topPad }}>
        <Text style={{ color: '#fff', fontWeight: '800', fontSize: 18, margin: 12 }}>
          Potong (crop) · {item?.name} hal. {page + 1}
        </Text>
        <Text style={{ color: '#9ca3af', marginHorizontal: 12, marginBottom: 8 }}>
          Seret jari di atas gambar untuk membuat kotak potong. Bagian di luar kotak tidak dicetak.
        </Text>
        <View style={{ alignItems: 'center', justifyContent: 'center', flex: 1 }}>
          {!img ? (
            <ActivityIndicator color="#fff" size="large" />
          ) : (
            <View style={{ width: box.w, height: box.h, backgroundColor: '#fff' }} {...pan.panHandlers}>
              <Image source={{ uri: img.uri }} style={{ width: box.w, height: box.h }} resizeMode="stretch" />
              <View pointerEvents="none" style={{ position: 'absolute', left: 0, top: 0, width: box.w, height: box.h }}>
                <View style={{ position: 'absolute', left: 0, top: 0, right: 0, height: crop.y * box.h, backgroundColor: 'rgba(0,0,0,0.55)' }} />
                <View style={{ position: 'absolute', left: 0, top: (crop.y + crop.h) * box.h, right: 0, bottom: 0, backgroundColor: 'rgba(0,0,0,0.55)' }} />
                <View style={{ position: 'absolute', left: 0, top: crop.y * box.h, width: crop.x * box.w, height: crop.h * box.h, backgroundColor: 'rgba(0,0,0,0.55)' }} />
                <View style={{ position: 'absolute', left: (crop.x + crop.w) * box.w, top: crop.y * box.h, right: 0, height: crop.h * box.h, backgroundColor: 'rgba(0,0,0,0.55)' }} />
                <View style={{ position: 'absolute', left: crop.x * box.w, top: crop.y * box.h, width: crop.w * box.w, height: crop.h * box.h, borderWidth: 2, borderColor: '#22d3ee' }} />
              </View>
            </View>
          )}
        </View>
        <View style={{ flexDirection: 'row', gap: 8, padding: 12, flexWrap: 'wrap' }}>
          <Pressable style={[s.btn, s.gray, { flex: 1 }]} onPress={() => setCrop(FULL_CROP)}>
            <Text style={s.btnTxt}>Semua</Text>
          </Pressable>
          <Pressable style={[s.btn, s.gray, { flex: 1 }, working && s.off]} onPress={doAuto} disabled={working}>
            <Text style={s.btnTxt}>{working ? '…' : 'Auto'}</Text>
          </Pressable>
        </View>
        <View style={{ flexDirection: 'row', gap: 8, padding: 12, paddingTop: 0, paddingBottom: 24 }}>
          <Pressable style={[s.btn, { flex: 1, backgroundColor: '#4b5563' }]} onPress={onClose}>
            <Text style={s.btnTxt}>Batal</Text>
          </Pressable>
          <Pressable
            style={[s.btn, s.primary, { flex: 2 }, tooSmall && s.off]}
            disabled={tooSmall}
            onPress={() => onSave(crop)}
          >
            <Text style={s.btnTxt}>Simpan potongan</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
