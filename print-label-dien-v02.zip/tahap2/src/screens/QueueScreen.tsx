import React, { useEffect, useState } from 'react';
import { Alert, FlatList, Image, Pressable, Text, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { CropModal } from '../components/CropModal';
import { PreviewModal } from '../components/PreviewModal';
import { Item, Job } from '../core/types';
import { getPageImage } from '../render';
import { AppApi } from '../useApp';
import { C, s, STATUS_COLOR, STATUS_LABEL } from '../ui';

function Thumb({ item, page }: { item: Item; page: number }) {
  const [uri, setUri] = useState<string | null>(null);
  useEffect(() => {
    let live = true;
    getPageImage(item, page).then((p) => live && setUri(p.uri)).catch(() => {});
    return () => {
      live = false;
    };
  }, [item.id, page]); // eslint-disable-line
  return uri ? (
    <Image source={{ uri }} style={{ width: 58, height: 58, borderRadius: 8, backgroundColor: '#eee' }} resizeMode="contain" />
  ) : (
    <View style={{ width: 58, height: 58, borderRadius: 8, backgroundColor: '#fee2e2' }} />
  );
}

export function QueueScreen({ app }: { app: AppApi }) {
  const { state, busy, paused, message } = app;
  const [sel, setSel] = useState<string[]>([]);
  const [cropJob, setCropJob] = useState<Job | null>(null);
  const [prevJob, setPrevJob] = useState<Job | null>(null);

  const itemOf = (j: Job) => state.items.find((i) => i.id === j.itemId) ?? null;
  const printer = app.activePrinter();
  const active = state.jobs.filter((j) => j.status !== 'TERKIRIM');
  const printedCount = app.printedItemIds().length;

  const pick = async () => {
    const r = await DocumentPicker.getDocumentAsync({ type: ['image/*', 'application/pdf'], multiple: true, copyToCacheDirectory: true });
    if (r.canceled) return;
    const res = await app.importFiles(r.assets.map((a) => ({ uri: a.uri, name: a.name, mime: a.mimeType ?? undefined })));
    if (res.added) Alert.alert('Berhasil', `${res.added} file (${res.jobs} halaman) masuk ke antrean.`);
  };

  const toggle = (id: string) => setSel((x) => (x.includes(id) ? x.filter((v) => v !== id) : [...x, id]));
  const ids = state.jobs.filter((j) => sel.includes(j.id) && j.status !== 'TERKIRIM').map((j) => j.id);
  const allWaiting = state.jobs.filter((j) => j.status === 'MENUNGGU' || j.status === 'GAGAL' || j.status === 'PERLU_PERIKSA').map((j) => j.id);

  const split = (it: Item) =>
    Alert.alert('Bagi halaman', 'Satu halaman PDF memuat berapa resi?', [
      { text: '1 (utuh)', onPress: () => app.splitItem(it.id, 1) },
      { text: '2 (atas/bawah)', onPress: () => app.splitItem(it.id, 2) },
      { text: '4 (2×2)', onPress: () => app.splitItem(it.id, 4) },
      { text: 'Batal', style: 'cancel' },
    ]);

  const deletePrinted = () =>
    Alert.alert(
      'Hapus file yang sudah tercetak?',
      `${printedCount} file akan dihapus permanen dari aplikasi ini. File asli di Shopee/galeri tidak ikut terhapus. Riwayat cetak tetap disimpan.`,
      [
        { text: 'Batal', style: 'cancel' },
        { text: 'Hapus', style: 'destructive', onPress: () => app.deleteItems(app.printedItemIds()) },
      ],
    );

  const deleteSelected = () => {
    const itemIds = Array.from(new Set(state.jobs.filter((j) => sel.includes(j.id)).map((j) => j.itemId)));
    if (!itemIds.length) return;
    Alert.alert('Hapus file?', `${itemIds.length} file (semua halamannya) dihapus permanen dari aplikasi ini. File asli tidak terhapus.`, [
      { text: 'Batal', style: 'cancel' },
      {
        text: 'Hapus',
        style: 'destructive',
        onPress: async () => {
          await app.deleteItems(itemIds);
          setSel([]);
        },
      },
    ]);
  };

  return (
    <View style={s.screen}>
      <Text style={s.title}>Antrean Cetak</Text>
      <Text style={s.sub}>
        {active.length} label menunggu · Printer: {printer ? `${printer.name} (${printer.widthMm}×${printer.heightMm} mm)` : 'belum dipilih'}
      </Text>
      {!!message && <Text style={[s.sub, { color: C.primary }]}>{message}</Text>}

      <FlatList
        data={state.jobs}
        keyExtractor={(j) => j.id}
        contentContainerStyle={{ paddingBottom: 200 }}
        ListEmptyComponent={
          <Text style={s.empty}>
            Belum ada file.{'\n'}Tekan “Impor File”, atau bagikan PDF/gambar resi dari aplikasi lain ke PRINT LABEL DIEN.
          </Text>
        }
        renderItem={({ item: j, index }) => {
          const it = itemOf(j);
          if (!it) return null;
          const on = sel.includes(j.id);
          const locked = j.status === 'MENCETAK';
          const c = j.crop;
          const cropped = !(c.x === 0 && c.y === 0 && c.w === 1 && c.h === 1);
          return (
            <View style={[s.card, on && { borderWidth: 2, borderColor: C.primary }]}>
              <Pressable style={s.row} onPress={() => toggle(j.id)}>
                <Thumb item={it} page={j.page} />
                <View style={{ flex: 1 }}>
                  <Text numberOfLines={1} style={s.h2}>
                    {it.name}
                  </Text>
                  <Text style={s.meta}>
                    Hal. {j.page + 1}/{it.pages} · {cropped ? 'dipotong' : 'utuh'}
                  </Text>
                  <Text style={[s.meta, { color: STATUS_COLOR[j.status], fontWeight: '700' }]}>
                    {STATUS_LABEL[j.status]}
                    {j.error ? ` — ${j.error}` : ''}
                  </Text>
                </View>
                <Text style={{ fontSize: 26 }}>{on ? '☑' : '☐'}</Text>
              </Pressable>
              <View style={[s.row, { marginTop: 8, flexWrap: 'wrap' }]}>
                <View style={s.row}>
                  <Pressable style={s.btnSm} onPress={() => app.setCopies(j.id, j.copies - 1)} disabled={locked}>
                    <Text style={s.btnSmTxt}>−</Text>
                  </Pressable>
                  <Text style={{ fontWeight: '700', minWidth: 54, textAlign: 'center' }}>{j.copies} salinan</Text>
                  <Pressable style={s.btnSm} onPress={() => app.setCopies(j.id, j.copies + 1)} disabled={locked}>
                    <Text style={s.btnSmTxt}>+</Text>
                  </Pressable>
                </View>
                <Pressable style={s.btnSm} onPress={() => setCropJob(j)} disabled={locked}>
                  <Text style={s.btnSmTxt}>Crop</Text>
                </Pressable>
                <Pressable style={s.btnSm} onPress={() => setPrevJob(j)}>
                  <Text style={s.btnSmTxt}>Pratinjau</Text>
                </Pressable>
                {it.mime === 'application/pdf' && (
                  <Pressable style={s.btnSm} onPress={() => split(it)} disabled={locked || busy}>
                    <Text style={s.btnSmTxt}>Bagi</Text>
                  </Pressable>
                )}
                <Pressable style={s.btnSm} onPress={() => app.moveJob(j.id, -1)} disabled={index === 0 || busy}>
                  <Text style={s.btnSmTxt}>↑</Text>
                </Pressable>
                <Pressable style={s.btnSm} onPress={() => app.moveJob(j.id, 1)} disabled={index === state.jobs.length - 1 || busy}>
                  <Text style={s.btnSmTxt}>↓</Text>
                </Pressable>
                {(j.status === 'GAGAL' || j.status === 'PERLU_PERIKSA' || j.status === 'TERKIRIM') && (
                  <Pressable style={s.btnSm} onPress={() => app.retryJob(j.id)} disabled={busy}>
                    <Text style={s.btnSmTxt}>{j.status === 'TERKIRIM' ? 'Cetak ulang' : 'Coba lagi'}</Text>
                  </Pressable>
                )}
              </View>
            </View>
          );
        }}
      />

      <View style={{ position: 'absolute', left: 0, right: 0, bottom: 0 }}>
        {busy && (
          <View style={[s.bar, { paddingBottom: 6 }]}>
            <Pressable style={[s.btn, s.gray, { flex: 1 }]} onPress={app.pause}>
              <Text style={s.btnTxt}>{paused ? 'Lanjutkan' : 'Jeda'}</Text>
            </Pressable>
            <Pressable style={[s.btn, s.danger, { flex: 1 }]} onPress={app.cancel}>
              <Text style={s.btnTxt}>Batalkan</Text>
            </Pressable>
          </View>
        )}
        <View style={[s.bar, { flexWrap: 'wrap' }]}>
          <Pressable style={[s.btn, s.gray, { flexGrow: 1 }, busy && s.off]} onPress={pick} disabled={busy}>
            <Text style={s.btnTxt}>Impor File</Text>
          </Pressable>
          <Pressable
            style={[s.btn, s.primary, { flexGrow: 2 }, (busy || !(ids.length || allWaiting.length)) && s.off]}
            disabled={busy || !(ids.length || allWaiting.length)}
            onPress={() => app.printJobs(ids.length ? ids : allWaiting)}
          >
            <Text style={s.btnTxt}>{ids.length ? `Cetak terpilih (${ids.length})` : `Cetak semua (${allWaiting.length})`}</Text>
          </Pressable>
          <Pressable style={[s.btn, s.danger, { flexGrow: 1 }, (busy || !sel.length) && s.off]} disabled={busy || !sel.length} onPress={deleteSelected}>
            <Text style={s.btnTxt}>Hapus ({sel.length})</Text>
          </Pressable>
          <Pressable style={[s.btn, { flexBasis: '100%', backgroundColor: '#7f1d1d' }, (busy || !printedCount) && s.off]} disabled={busy || !printedCount} onPress={deletePrinted}>
            <Text style={s.btnTxt}>Hapus semua yang sudah tercetak ({printedCount})</Text>
          </Pressable>
        </View>
      </View>

      <CropModal
        visible={!!cropJob}
        item={cropJob ? itemOf(cropJob) : null}
        page={cropJob?.page ?? 0}
        initial={cropJob?.crop ?? { x: 0, y: 0, w: 1, h: 1 }}
        onClose={() => setCropJob(null)}
        onSave={(c) => {
          if (cropJob) app.setCrop(cropJob.id, c);
          setCropJob(null);
        }}
      />
      <PreviewModal
        visible={!!prevJob}
        item={prevJob ? itemOf(prevJob) : null}
        job={prevJob}
        printer={printer}
        settings={state.settings}
        onClose={() => setPrevJob(null)}
        onPrint={() => {
          const id = prevJob?.id;
          setPrevJob(null);
          if (id) app.printJobs([id]);
        }}
      />
    </View>
  );
}
