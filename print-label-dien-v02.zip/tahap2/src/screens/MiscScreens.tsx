import React from 'react';
import { Alert, FlatList, Pressable, Switch, Text, View } from 'react-native';
import { AppApi } from '../useApp';
import { C, s, STATUS_LABEL } from '../ui';

export function HistoryScreen({ app }: { app: AppApi }) {
  const { history } = app.state;
  return (
    <View style={s.screen}>
      <Text style={s.title}>Riwayat Cetak</Text>
      <Text style={s.sub}>“Berhasil dikirim” berarti data sudah diterima printer, bukan jaminan label pasti keluar.</Text>
      <FlatList
        data={history}
        keyExtractor={(h) => h.id}
        contentContainerStyle={{ paddingBottom: 120 }}
        ListEmptyComponent={<Text style={s.empty}>Belum ada riwayat.</Text>}
        renderItem={({ item: h }) => (
          <View style={s.card}>
            <Text style={s.h2} numberOfLines={1}>
              {h.name} · hal. {h.page + 1}
            </Text>
            <Text style={s.meta}>
              {new Date(h.at).toLocaleString('id-ID')} · {h.printerName} · {h.copies} salinan · {STATUS_LABEL[h.status]}
            </Text>
          </View>
        )}
      />
      {!!history.length && (
        <View style={[s.bar, { position: 'absolute', left: 0, right: 0, bottom: 0 }]}>
          <Pressable
            style={[s.btn, s.danger, { flex: 1 }]}
            onPress={() =>
              Alert.alert('Hapus riwayat?', 'Hanya riwayat yang dihapus, bukan file.', [
                { text: 'Batal', style: 'cancel' },
                { text: 'Hapus', style: 'destructive', onPress: app.clearHistory },
              ])
            }
          >
            <Text style={s.btnTxt}>Hapus riwayat</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

export function SettingsScreen({ app }: { app: AppApi }) {
  const st = app.state.settings;
  return (
    <View style={s.screen}>
      <Text style={s.title}>Pengaturan</Text>
      <View style={[s.card, { marginTop: 8 }]}>
        <View style={[s.row, { justifyContent: 'space-between' }]}>
          <View style={{ flex: 1 }}>
            <Text style={s.h2}>Hapus otomatis setelah tercetak</Text>
            <Text style={s.meta}>Salinan file dihapus begitu semua halamannya berhasil dikirim. File asli tidak disentuh. Riwayat tetap ada.</Text>
          </View>
          <Switch value={st.autoDelete} onValueChange={(v) => app.setSettings({ autoDelete: v })} />
        </View>
      </View>
      <View style={s.card}>
        <View style={[s.row, { justifyContent: 'space-between' }]}>
          <View style={{ flex: 1 }}>
            <Text style={s.h2}>Dithering (untuk foto)</Text>
            <Text style={s.meta}>Matikan untuk resi/barcode/QR agar tepi tajam dan terbaca scanner.</Text>
          </View>
          <Switch value={st.dither} onValueChange={(v) => app.setSettings({ dither: v })} />
        </View>
      </View>
      <View style={s.card}>
        <Text style={s.h2}>Ambang hitam-putih: {st.threshold}</Text>
        <Text style={s.meta}>Naikkan jika cetakan terlalu pucat, turunkan jika terlalu pekat.</Text>
        <View style={[s.row, { marginTop: 8 }]}>
          <Pressable style={s.btnSm} onPress={() => app.setSettings({ threshold: Math.max(60, st.threshold - 10) })}>
            <Text style={s.btnSmTxt}>−10</Text>
          </Pressable>
          <Pressable style={s.btnSm} onPress={() => app.setSettings({ threshold: Math.min(230, st.threshold + 10) })}>
            <Text style={s.btnSmTxt}>+10</Text>
          </Pressable>
        </View>
      </View>
      <View style={s.card}>
        <Text style={s.h2}>Penyesuaian ukuran</Text>
        <Text style={s.meta}>“Sesuaikan” menampilkan seluruh isi tanpa terpotong. “Penuhi” mengisi label penuh dan bisa memotong tepi.</Text>
        <View style={[s.row, { marginTop: 8 }]}>
          {(['fit', 'fill'] as const).map((m) => (
            <Pressable key={m} style={[s.btnSm, st.fitMode === m && { backgroundColor: C.primary }]} onPress={() => app.setSettings({ fitMode: m })}>
              <Text style={[s.btnSmTxt, st.fitMode === m && { color: '#fff' }]}>{m === 'fit' ? 'Sesuaikan' : 'Penuhi'}</Text>
            </Pressable>
          ))}
        </View>
      </View>
      <Text style={[s.meta, { margin: 16 }]}>PRINT LABEL DIEN v0.2 · semua data disimpan lokal di HP ini.</Text>
    </View>
  );
}
