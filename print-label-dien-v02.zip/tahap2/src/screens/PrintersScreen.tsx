import React, { useState } from 'react';
import { Alert, Platform, Pressable, ScrollView, Switch, Text, TextInput, View } from 'react-native';
import { defaultPrinter, PrinterProfile } from '../core/types';
import { FoundDevice, scanBle } from '../printer/ble';
import { pairedClassic } from '../printer/classic';
import { ensureBtPermissions } from '../printer/transport';
import { AppApi } from '../useApp';
import { C, s } from '../ui';

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 5);

function Num({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  const [txt, setTxt] = useState(String(value));
  return (
    <View style={{ width: '31%' }}>
      <Text style={s.label}>{label}</Text>
      <TextInput
        style={s.input}
        keyboardType="numeric"
        value={txt}
        onChangeText={(t) => {
          setTxt(t);
          const n = Number(t.replace(',', '.'));
          if (!Number.isNaN(n) && t.trim() !== '') onChange(n);
        }}
      />
    </View>
  );
}

export function PrintersScreen({ app }: { app: AppApi }) {
  const { state, busy } = app;
  const [found, setFound] = useState<(FoundDevice & { kind: 'ble' | 'classic' })[]>([]);
  const [scanning, setScanning] = useState(false);

  const scan = async () => {
    if (!(await ensureBtPermissions())) {
      Alert.alert('Izin Bluetooth ditolak', 'Aktifkan izin Bluetooth/Perangkat sekitar untuk aplikasi ini di Pengaturan HP.');
      return;
    }
    setFound([]);
    setScanning(true);
    try {
      if (Platform.OS === 'android') {
        const paired = await pairedClassic().catch(() => []);
        setFound((f) => [...f, ...paired.map((d) => ({ id: d.id, name: d.name, rssi: null, kind: 'classic' as const }))]);
      }
      await scanBle((d) => setFound((f) => (f.some((x) => x.id === d.id && x.kind === 'ble') ? f : [...f, { ...d, kind: 'ble' as const }])));
    } catch (e: any) {
      Alert.alert('Gagal mencari', String(e?.message ?? e) + '\nPastikan Bluetooth menyala.');
    } finally {
      setScanning(false);
    }
  };

  const add = (d: FoundDevice & { kind: 'ble' | 'classic' }) => {
    app.addPrinter(defaultPrinter({ id: uid(), name: d.name, transport: d.kind, address: d.id }));
    Alert.alert('Printer ditambahkan', 'Atur ukuran label lalu tekan “Cetak halaman uji”.');
  };

  const field = (p: PrinterProfile, patch: Partial<PrinterProfile>) => app.updatePrinter(p.id, patch);

  return (
    <View style={s.screen}>
      <Text style={s.title}>Printer Saya</Text>
      <Text style={s.sub}>Tambah printer, atur ukuran label, lalu uji cetak.</Text>
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        {state.printers.map((p) => {
          const active = state.activePrinterId === p.id;
          return (
            <View key={p.id} style={[s.card, active && { borderWidth: 2, borderColor: C.primary }]}>
              <Text style={s.h2}>
                {p.name} {active ? '· AKTIF' : ''}
              </Text>
              <Text style={s.meta}>
                {p.transport === 'ble' ? 'Bluetooth LE' : 'Bluetooth Classic'} · {p.address}
              </Text>
              <Text style={s.meta}>Status kompatibilitas: BELUM DIUJI — jalankan halaman uji.</Text>

              <Text style={s.label}>Protokol</Text>
              <View style={s.row}>
                {(['tspl', 'escpos'] as const).map((k) => (
                  <Pressable key={k} style={[s.btnSm, p.protocol === k && { backgroundColor: C.primary }]} onPress={() => field(p, { protocol: k })}>
                    <Text style={[s.btnSmTxt, p.protocol === k && { color: '#fff' }]}>{k === 'tspl' ? 'TSPL (label)' : 'ESC/POS (struk)'}</Text>
                  </Pressable>
                ))}
              </View>

              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
                <Num label="Lebar (mm)" value={p.widthMm} onChange={(n) => field(p, { widthMm: n })} />
                <Num label="Tinggi (mm)" value={p.heightMm} onChange={(n) => field(p, { heightMm: n })} />
                <Num label="DPI" value={p.dpi} onChange={(n) => field(p, { dpi: n })} />
                <Num label="Margin (mm)" value={p.marginMm} onChange={(n) => field(p, { marginMm: n })} />
                <Num label="Gap (mm)" value={p.gapMm} onChange={(n) => field(p, { gapMm: n })} />
                <Num label="Kerapatan 0-15" value={p.density} onChange={(n) => field(p, { density: Math.min(15, Math.max(0, n)) })} />
                <Num label="Kecepatan 1-6" value={p.speed} onChange={(n) => field(p, { speed: Math.min(6, Math.max(1, n)) })} />
              </View>

              <View style={[s.row, { marginTop: 10, justifyContent: 'space-between' }]}>
                <Text style={{ flex: 1, color: C.text }}>Balik hitam/putih (aktifkan jika hasil cetak terbalik)</Text>
                <Switch value={p.invert} onValueChange={(v) => field(p, { invert: v })} />
              </View>

              <View style={[s.row, { marginTop: 10, flexWrap: 'wrap' }]}>
                <Pressable style={[s.btn, s.primary, busy && s.off]} disabled={busy} onPress={() => app.testPrint(p)}>
                  <Text style={s.btnTxt}>Cetak halaman uji</Text>
                </Pressable>
                {!active && (
                  <Pressable style={[s.btn, s.gray]} onPress={() => app.setActivePrinter(p.id)}>
                    <Text style={s.btnTxt}>Jadikan aktif</Text>
                  </Pressable>
                )}
                <Pressable
                  style={[s.btn, s.danger]}
                  onPress={() =>
                    Alert.alert('Hapus printer?', p.name, [
                      { text: 'Batal', style: 'cancel' },
                      { text: 'Hapus', style: 'destructive', onPress: () => app.removePrinter(p.id) },
                    ])
                  }
                >
                  <Text style={s.btnTxt}>Hapus</Text>
                </Pressable>
              </View>
            </View>
          );
        })}

        <View style={s.card}>
          <Text style={s.h2}>Cari printer</Text>
          <Text style={s.meta}>
            Nyalakan printer & Bluetooth.{Platform.OS === 'android' ? ' Printer Classic harus dipasangkan dulu di Pengaturan Bluetooth HP.' : ' iPhone hanya mendukung printer BLE.'}
          </Text>
          <Pressable style={[s.btn, s.primary, { marginTop: 8 }, (scanning || busy) && s.off]} disabled={scanning || busy} onPress={scan}>
            <Text style={s.btnTxt}>{scanning ? 'Mencari…' : 'Cari printer Bluetooth'}</Text>
          </Pressable>
          {found.map((d) => (
            <Pressable key={d.kind + d.id} style={[s.row, { paddingVertical: 10, borderBottomWidth: 1, borderColor: C.line }]} onPress={() => add(d)}>
              <View style={{ flex: 1 }}>
                <Text style={s.h2}>{d.name}</Text>
                <Text style={s.meta}>
                  {d.kind === 'ble' ? 'BLE' : 'Classic (dipasangkan)'} · {d.id}
                  {d.rssi != null ? ` · ${d.rssi} dBm` : ''}
                </Text>
              </View>
              <Text style={{ color: C.primary, fontWeight: '700' }}>Tambah</Text>
            </Pressable>
          ))}
          {!scanning && !found.length && <Text style={s.meta}>Belum ada hasil. Cari nama printer (mis. AL-100BLP).</Text>}
        </View>
      </ScrollView>
    </View>
  );
}
