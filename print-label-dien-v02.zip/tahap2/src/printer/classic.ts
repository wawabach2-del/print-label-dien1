import { Platform } from 'react-native';
import { toBase64 } from '../core/bits';
import { PrinterProfile } from '../core/types';
import type { Transport } from './transport';

// Bluetooth Classic (SPP) hanya ada di Android. Dimuat malas agar iOS tidak error.
function lib(): any {
  if (Platform.OS !== 'android') throw new Error('Bluetooth Classic hanya tersedia di Android.');
  return require('react-native-bluetooth-classic').default;
}

export async function pairedClassic(): Promise<{ id: string; name: string }[]> {
  const list: any[] = await lib().getBondedDevices();
  return list.map((d) => ({ id: d.address as string, name: (d.name as string) ?? d.address }));
}

export class ClassicTransport implements Transport {
  private dev: any = null;
  constructor(private p: PrinterProfile) {}

  async connect() {
    const L = lib();
    this.dev = await L.connectToDevice(this.p.address);
    if (!this.dev) throw new Error('Gagal terhubung (Classic). Pastikan printer sudah dipasangkan di Pengaturan Bluetooth.');
  }

  async write(data: Uint8Array) {
    if (!this.dev) throw new Error('Classic belum terhubung.');
    const step = 2048;
    for (let i = 0; i < data.length; i += step) {
      await this.dev.write(toBase64(data.subarray(i, i + step)), 'base64');
    }
  }

  async disconnect() {
    try {
      await this.dev?.disconnect();
    } catch {}
    this.dev = null;
  }
}
