import { PermissionsAndroid, Platform } from 'react-native';
import { PrinterProfile } from '../core/types';
import { BleTransport } from './ble';
import { ClassicTransport } from './classic';

export interface Transport {
  connect(): Promise<void>;
  write(data: Uint8Array): Promise<void>;
  disconnect(): Promise<void>;
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export async function ensureBtPermissions(): Promise<boolean> {
  if (Platform.OS !== 'android') return true; // iOS meminta izin sendiri saat Bluetooth dipakai
  const v = Number(Platform.Version);
  const need =
    v >= 31
      ? [
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
        ]
      : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];
  const res = await PermissionsAndroid.requestMultiple(need);
  return need.every((p) => res[p] === PermissionsAndroid.RESULTS.GRANTED);
}

export function makeTransport(
  p: PrinterProfile,
  onResolved?: (serviceUUID: string, charUUID: string) => void,
): Transport {
  return p.transport === 'ble' ? new BleTransport(p, onResolved) : new ClassicTransport(p);
}
