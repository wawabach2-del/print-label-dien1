import { BleManager, Characteristic } from 'react-native-ble-plx';
import { Platform } from 'react-native';
import { toBase64 } from '../core/bits';
import { PrinterProfile } from '../core/types';
import type { Transport } from './transport';

let manager: BleManager | null = null;
export function bleManager(): BleManager {
  if (!manager) manager = new BleManager();
  return manager;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export type FoundDevice = { id: string; name: string; rssi: number | null };

// Cari perangkat BLE di sekitar selama `ms` milidetik.
export function scanBle(onFound: (d: FoundDevice) => void, ms = 8000): Promise<void> {
  const m = bleManager();
  return new Promise((resolve, reject) => {
    const seen = new Set<string>();
    m.startDeviceScan(null, { allowDuplicates: false }, (err, dev) => {
      if (err) {
        m.stopDeviceScan();
        reject(err);
        return;
      }
      if (dev && !seen.has(dev.id)) {
        seen.add(dev.id);
        onFound({ id: dev.id, name: dev.name ?? dev.localName ?? '(tanpa nama)', rssi: dev.rssi });
      }
    });
    setTimeout(() => {
      m.stopDeviceScan();
      resolve();
    }, ms);
  });
}

// UUID karakteristik tulis yang umum dipakai printer thermal murah.
const PREFERRED = ['ffe1', 'ff02', '2af1', 'bef8d6c9-9c21-4c9e-b632-bd58c1009f9f', '49535343-8841-43f4-a8d4-ecbe34729bb3'];

export class BleTransport implements Transport {
  private ch: Characteristic | null = null;
  private chunk = 20;

  constructor(
    private p: PrinterProfile,
    private onResolved?: (serviceUUID: string, charUUID: string) => void,
  ) {}

  async connect() {
    const m = bleManager();
    let dev = await m.connectToDevice(this.p.address, {
      timeout: 12000,
      requestMTU: Platform.OS === 'android' ? 247 : undefined,
    });
    dev = await dev.discoverAllServicesAndCharacteristics();
    const cands: Characteristic[] = [];
    for (const s of await dev.services()) {
      for (const c of await s.characteristics()) {
        if (c.isWritableWithResponse || c.isWritableWithoutResponse) cands.push(c);
      }
    }
    if (!cands.length) throw new Error('Tidak ada karakteristik tulis BLE pada perangkat ini.');
    const norm = (u: string) => u.toLowerCase();
    const stored = cands.find(
      (c) => norm(c.serviceUUID) === norm(this.p.serviceUUID ?? '-') && norm(c.uuid) === norm(this.p.charUUID ?? '-'),
    );
    const pref = cands.find((c) => PREFERRED.some((u) => norm(c.uuid).includes(u)));
    this.ch = stored ?? pref ?? cands[0];
    this.onResolved?.(this.ch.serviceUUID, this.ch.uuid);
    const mtu = (dev as any).mtu as number | undefined;
    this.chunk = Math.min(512, Math.max(20, (mtu ?? 23) - 3));
  }

  async write(data: Uint8Array) {
    const ch = this.ch;
    if (!ch) throw new Error('BLE belum terhubung.');
    for (let i = 0; i < data.length; i += this.chunk) {
      const b64 = toBase64(data.subarray(i, i + this.chunk));
      if (ch.isWritableWithResponse) await ch.writeWithResponse(b64);
      else {
        await ch.writeWithoutResponse(b64);
        await sleep(12);
      }
    }
  }

  async disconnect() {
    try {
      await bleManager().cancelDeviceConnection(this.p.address);
    } catch {}
    this.ch = null;
  }
}
