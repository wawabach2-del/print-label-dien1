import { Image } from 'react-native';
import { manipulateAsync, SaveFormat } from 'expo-image-manipulator';
import PdfThumbnail from 'react-native-pdf-thumbnail';
import UPNG from 'upng-js';
import {
  binarize,
  contentBox,
  fromBase64,
  layoutInBox,
  mmToDots,
  packBits,
  rgbaToGrayCanvas,
  toBase64,
} from './core/bits';
import { escposLabel, tsplLabel } from './core/protocols';
import { Crop, Item, Job, PrinterProfile, Settings } from './core/types';

export type PageImage = { uri: string; width: number; height: number };
const cache = new Map<string, PageImage>();

function imageSize(uri: string): Promise<{ width: number; height: number }> {
  return new Promise((res, rej) => Image.getSize(uri, (width, height) => res({ width, height }), rej));
}

export async function countPages(item: { uri: string; mime: string }): Promise<number> {
  if (item.mime !== 'application/pdf') return 1;
  try {
    const all = await PdfThumbnail.generateAllPages(item.uri, 10);
    return Math.max(1, all.length);
  } catch {
    return 1;
  }
}

// Gambar satu halaman (PDF dirender ke gambar; gambar dipakai apa adanya).
export async function getPageImage(item: Item, page: number): Promise<PageImage> {
  const key = item.id + ':' + page;
  const hit = cache.get(key);
  if (hit) return hit;
  let out: PageImage;
  if (item.mime === 'application/pdf') {
    const r = await PdfThumbnail.generate(item.uri, page, 100);
    out = { uri: r.uri, width: r.width, height: r.height };
  } else {
    const s = await imageSize(item.uri);
    out = { uri: item.uri, width: s.width, height: s.height };
  }
  cache.set(key, out);
  return out;
}

export function forgetItem(itemId: string) {
  for (const k of Array.from(cache.keys())) if (k.startsWith(itemId + ':')) cache.delete(k);
}

function decodePng(b64: string) {
  const buf = fromBase64(b64);
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
  const img = UPNG.decode(ab);
  const rgba = new Uint8Array(UPNG.toRGBA8(img)[0]);
  return { rgba, w: img.width, h: img.height };
}

// "Potong otomatis": buang tepi putih di sekeliling isi halaman.
export async function autoCrop(item: Item, page: number): Promise<Crop | null> {
  const src = await getPageImage(item, page);
  const r = await manipulateAsync(src.uri, [{ resize: { width: 300 } }], {
    format: SaveFormat.PNG,
    base64: true,
  });
  const { rgba, w, h } = decodePng(r.base64!);
  const gray = rgbaToGrayCanvas(rgba, w, h, w, h);
  return contentBox(gray, w, h);
}

export type Rendered = { mono: Uint8Array; w: number; h: number };

// Halaman + crop -> bitmap hitam-putih seukuran label (kelipatan 8 titik).
export async function renderMono(
  item: Item,
  job: Job,
  p: PrinterProfile,
  s: Settings,
): Promise<Rendered> {
  const src = await getPageImage(item, job.page);
  const c = job.crop;
  const cw = Math.max(1, Math.round(c.w * src.width));
  const ch = Math.max(1, Math.round(c.h * src.height));
  const cx = Math.min(src.width - 1, Math.max(0, Math.round(c.x * src.width)));
  const cy = Math.min(src.height - 1, Math.max(0, Math.round(c.y * src.height)));

  const labelW = Math.ceil(mmToDots(p.widthMm, p.dpi) / 8) * 8;
  const labelH = mmToDots(p.heightMm, p.dpi);
  const m = mmToDots(p.marginMm, p.dpi);
  const lay = layoutInBox(cw, ch, labelW - 2 * m, labelH - 2 * m, s.fitMode);

  const r = await manipulateAsync(
    src.uri,
    [
      { crop: { originX: cx, originY: cy, width: Math.min(cw, src.width - cx), height: Math.min(ch, src.height - cy) } },
      { resize: { width: lay.w, height: lay.h } },
    ],
    { format: SaveFormat.PNG, base64: true },
  );
  const { rgba, w, h } = decodePng(r.base64!);
  const gray = rgbaToGrayCanvas(rgba, w, h, labelW, labelH);
  return { mono: binarize(gray, labelW, labelH, s.threshold, s.dither), w: labelW, h: labelH };
}

// Pratinjau = bitmap yang SAMA dengan yang dikirim ke printer.
export function monoPreviewUri(r: Rendered): string {
  const rgba = new Uint8Array(r.w * r.h * 4);
  for (let i = 0; i < r.mono.length; i++) {
    const v = r.mono[i];
    rgba[i * 4] = v;
    rgba[i * 4 + 1] = v;
    rgba[i * 4 + 2] = v;
    rgba[i * 4 + 3] = 255;
  }
  const png = UPNG.encode([rgba.buffer as ArrayBuffer], r.w, r.h, 2);
  return 'data:image/png;base64,' + toBase64(new Uint8Array(png));
}

export function encodeJob(r: Rendered, p: PrinterProfile, copies: number): Uint8Array {
  if (p.protocol === 'escpos') {
    const { data, widthBytes } = packBits(r.mono, r.w, r.h, true);
    return escposLabel(data, widthBytes, r.h, copies);
  }
  // TSPL BITMAP mode 0: bit 0 = hitam. Profil.invert membalik jika printer ternyata sebaliknya.
  const { data, widthBytes } = packBits(r.mono, r.w, r.h, p.invert);
  return tsplLabel(data, widthBytes, r.h, p, copies);
}
