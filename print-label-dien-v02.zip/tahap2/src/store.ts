import * as FS from 'expo-file-system/legacy';
import { AppState, DEFAULT_SETTINGS, Item } from './core/types';

// Semua file kerja ada di folder aplikasi. File asli (Shopee/galeri/WhatsApp) tidak pernah disentuh.
const DIR = FS.documentDirectory + 'antrean/';
const STATE = FS.documentDirectory + 'state.json';

export const emptyState = (): AppState => ({
  items: [],
  jobs: [],
  printers: [],
  history: [],
  settings: { ...DEFAULT_SETTINGS },
});

async function ensureDir() {
  const info = await FS.getInfoAsync(DIR);
  if (!info.exists) await FS.makeDirectoryAsync(DIR, { intermediates: true });
}

export async function loadState(): Promise<AppState> {
  const base = emptyState();
  const info = await FS.getInfoAsync(STATE);
  if (!info.exists) return base;
  try {
    const s: AppState = { ...base, ...JSON.parse(await FS.readAsStringAsync(STATE)) };
    s.settings = { ...DEFAULT_SETTINGS, ...s.settings };
    // buang item yang filenya sudah hilang
    const alive: Item[] = [];
    for (const it of s.items) {
      if ((await FS.getInfoAsync(it.uri)).exists) alive.push(it);
    }
    const ids = new Set(alive.map((i) => i.id));
    s.items = alive;
    s.jobs = s.jobs
      .filter((j) => ids.has(j.itemId))
      // aplikasi tertutup saat mengirim -> jangan kirim ulang otomatis (cegah cetak ganda)
      .map((j) =>
        j.status === 'MENCETAK'
          ? { ...j, status: 'PERLU_PERIKSA' as const, error: 'Aplikasi tertutup saat mengirim. Periksa printer.' }
          : j,
      );
    return s;
  } catch {
    return base;
  }
}

let writing: Promise<void> = Promise.resolve();
export function saveState(s: AppState) {
  const json = JSON.stringify(s);
  writing = writing.then(() => FS.writeAsStringAsync(STATE, json)).catch(() => {});
  return writing;
}

export function guessMime(name: string, mime?: string): string {
  if (mime && mime !== 'application/octet-stream') return mime;
  const n = name.toLowerCase();
  if (n.endsWith('.pdf')) return 'application/pdf';
  if (n.endsWith('.png')) return 'image/png';
  if (n.endsWith('.jpg') || n.endsWith('.jpeg')) return 'image/jpeg';
  if (n.endsWith('.bmp')) return 'image/bmp';
  return mime ?? '';
}

export function isSupported(mime: string, name: string) {
  return (
    ['image/png', 'image/jpeg', 'image/bmp', 'application/pdf'].includes(mime) ||
    /\.(png|jpe?g|bmp|pdf)$/i.test(name)
  );
}

function fileUri(p: string) {
  return p.startsWith('/') ? 'file://' + p : p;
}

// Salin file sumber ke folder aplikasi.
export async function copyIn(
  f: { uri: string; name: string; mime?: string },
): Promise<Omit<Item, 'pages'> | null> {
  await ensureDir();
  const mime = guessMime(f.name, f.mime);
  if (!isSupported(mime, f.name)) return null;
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const dest = DIR + id + '_' + f.name.replace(/[^\w.\-]+/g, '_');
  try {
    await FS.copyAsync({ from: fileUri(f.uri), to: dest });
    const info: any = await FS.getInfoAsync(dest);
    return { id, name: f.name, uri: dest, mime, size: info.size ?? 0, addedAt: Date.now() };
  } catch {
    return null;
  }
}

// Hapus HANYA salinan di folder aplikasi.
export async function deleteCopy(uri: string) {
  if (uri.startsWith(DIR)) await FS.deleteAsync(uri, { idempotent: true });
}
