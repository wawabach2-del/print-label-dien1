import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { tsplTestPage, escposTestPage } from './core/protocols';
import {
  AppState,
  Crop,
  FULL_CROP,
  Item,
  Job,
  JobStatus,
  PrinterProfile,
  Settings,
} from './core/types';
import { countPages, encodeJob, forgetItem, renderMono } from './render';
import { copyIn, deleteCopy, emptyState, loadState, saveState } from './store';
import { ensureBtPermissions, makeTransport, sleep } from './printer/transport';

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

export type Incoming = { uri: string; name: string; mime?: string };

export function useApp() {
  const [state, setState] = useState<AppState>(emptyState());
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [paused, setPaused] = useState(false);
  const [message, setMessage] = useState('');
  const ref = useRef<AppState>(state);
  const run = useRef({ running: false, cancel: false, pause: false });

  const commit = useCallback((fn: (s: AppState) => AppState) => {
    const next = fn(ref.current);
    ref.current = next;
    setState(next);
    saveState(next);
  }, []);

  useEffect(() => {
    loadState().then((s) => {
      ref.current = s;
      setState(s);
      setReady(true);
      saveState(s);
    });
  }, []);

  // ---------- impor & hapus ----------
  const importFiles = useCallback(
    async (files: Incoming[]) => {
      const items: Item[] = [];
      const jobs: Job[] = [];
      const rejected: string[] = [];
      for (const f of files) {
        const c = await copyIn(f);
        if (!c) {
          rejected.push(f.name);
          continue;
        }
        const pages = await countPages(c);
        items.push({ ...c, pages });
        for (let p = 0; p < pages; p++) {
          jobs.push({ id: uid(), itemId: c.id, page: p, crop: FULL_CROP, copies: 1, status: 'MENUNGGU' });
        }
      }
      if (items.length) commit((s) => ({ ...s, items: [...s.items, ...items], jobs: [...s.jobs, ...jobs] }));
      if (rejected.length) {
        Alert.alert('Sebagian file tidak dapat diimpor', 'Format tidak didukung atau gagal disalin:\n' + rejected.join('\n'));
      }
      return { added: items.length, jobs: jobs.length };
    },
    [commit],
  );

  const deleteItems = useCallback(
    async (ids: string[]) => {
      const set = new Set(ids);
      for (const it of ref.current.items.filter((i) => set.has(i.id))) {
        await deleteCopy(it.uri);
        forgetItem(it.id);
      }
      commit((s) => ({
        ...s,
        items: s.items.filter((i) => !set.has(i.id)),
        jobs: s.jobs.filter((j) => !set.has(j.itemId)),
      }));
    },
    [commit],
  );

  // item yang SEMUA halamannya sudah TERKIRIM
  const printedItemIds = useCallback((s: AppState = ref.current) => {
    return s.items
      .filter((it) => {
        const js = s.jobs.filter((j) => j.itemId === it.id);
        return js.length > 0 && js.every((j) => j.status === 'TERKIRIM');
      })
      .map((it) => it.id);
  }, []);

  // ---------- pengeditan pekerjaan ----------
  const setCrop = useCallback(
    (jobId: string, crop: Crop) =>
      commit((s) => ({ ...s, jobs: s.jobs.map((j) => (j.id === jobId ? { ...j, crop, status: (j.status === 'TERKIRIM' ? j.status : 'MENUNGGU') as JobStatus, error: undefined } : j)) })),
    [commit],
  );
  const setCopies = useCallback(
    (jobId: string, n: number) =>
      commit((s) => ({ ...s, jobs: s.jobs.map((j) => (j.id === jobId ? { ...j, copies: Math.min(99, Math.max(1, n)) } : j)) })),
    [commit],
  );
  const moveJob = useCallback(
    (jobId: string, dir: -1 | 1) =>
      commit((s) => {
        const i = s.jobs.findIndex((j) => j.id === jobId);
        const k = i + dir;
        if (i < 0 || k < 0 || k >= s.jobs.length) return s;
        const jobs = s.jobs.slice();
        [jobs[i], jobs[k]] = [jobs[k], jobs[i]];
        return { ...s, jobs };
      }),
    [commit],
  );
  const retryJob = useCallback(
    (jobId: string) =>
      commit((s) => ({ ...s, jobs: s.jobs.map((j) => (j.id === jobId ? { ...j, status: 'MENUNGGU' as const, error: undefined } : j)) })),
    [commit],
  );

  // Pecah tiap halaman item menjadi 1, 2 (atas/bawah) atau 4 (2x2) label. Untuk PDF Shopee yang memuat beberapa resi per halaman.
  const splitItem = useCallback(
    (itemId: string, parts: 1 | 2 | 4) =>
      commit((s) => {
        const it = s.items.find((i) => i.id === itemId);
        if (!it) return s;
        const keep = s.jobs.filter((j) => j.itemId !== itemId || j.status === 'TERKIRIM');
        let at = keep.findIndex((j) => j.itemId === itemId);
        if (at < 0) {
          const orig = s.jobs.findIndex((j) => j.itemId === itemId);
          at = orig < 0 ? keep.length : Math.min(orig, keep.length);
        }
        const tiles: Crop[] =
          parts === 1
            ? [FULL_CROP]
            : parts === 2
              ? [
                  { x: 0, y: 0, w: 1, h: 0.5 },
                  { x: 0, y: 0.5, w: 1, h: 0.5 },
                ]
              : [
                  { x: 0, y: 0, w: 0.5, h: 0.5 },
                  { x: 0.5, y: 0, w: 0.5, h: 0.5 },
                  { x: 0, y: 0.5, w: 0.5, h: 0.5 },
                  { x: 0.5, y: 0.5, w: 0.5, h: 0.5 },
                ];
        const fresh: Job[] = [];
        for (let p = 0; p < it.pages; p++) {
          for (const crop of tiles) fresh.push({ id: uid(), itemId, page: p, crop, copies: 1, status: 'MENUNGGU' });
        }
        const jobs = keep.slice();
        jobs.splice(at, 0, ...fresh);
        return { ...s, jobs };
      }),
    [commit],
  );

  // ---------- printer & pengaturan ----------
  const addPrinter = useCallback(
    (p: PrinterProfile) =>
      commit((s) => ({ ...s, printers: [...s.printers.filter((x) => x.id !== p.id), p], activePrinterId: s.activePrinterId ?? p.id })),
    [commit],
  );
  const updatePrinter = useCallback(
    (id: string, patch: Partial<PrinterProfile>) =>
      commit((s) => ({ ...s, printers: s.printers.map((p) => (p.id === id ? { ...p, ...patch } : p)) })),
    [commit],
  );
  const removePrinter = useCallback(
    (id: string) =>
      commit((s) => ({
        ...s,
        printers: s.printers.filter((p) => p.id !== id),
        activePrinterId: s.activePrinterId === id ? undefined : s.activePrinterId,
      })),
    [commit],
  );
  const setActivePrinter = useCallback((id: string) => commit((s) => ({ ...s, activePrinterId: id })), [commit]);
  const setSettings = useCallback((patch: Partial<Settings>) => commit((s) => ({ ...s, settings: { ...s.settings, ...patch } })), [commit]);
  const clearHistory = useCallback(() => commit((s) => ({ ...s, history: [] })), [commit]);

  const activePrinter = useCallback((): PrinterProfile | undefined => {
    const s = ref.current;
    return s.printers.find((p) => p.id === s.activePrinterId);
  }, []);

  // ---------- cetak ----------
  const setStatus = (jobId: string, status: JobStatus, error?: string) =>
    commit((s) => ({ ...s, jobs: s.jobs.map((j) => (j.id === jobId ? { ...j, status, error } : j)) }));

  const printJobs = useCallback(
    async (jobIds: string[]) => {
      if (run.current.running) return; // cegah kirim ganda akibat tombol ditekan berulang
      const printer = activePrinter();
      if (!printer) {
        Alert.alert('Belum ada printer', 'Buka tab Printer, tambah printer, lalu jadikan aktif.');
        return;
      }
      if (!jobIds.length) return;
      run.current = { running: true, cancel: false, pause: false };
      setPaused(false);
      setBusy(true);
      const transport = makeTransport(printer, (serviceUUID, charUUID) => {
        if (printer.serviceUUID !== serviceUUID || printer.charUUID !== charUUID) updatePrinter(printer.id, { serviceUUID, charUUID });
      });
      try {
        if (!(await ensureBtPermissions())) throw new Error('Izin Bluetooth ditolak.');
        setMessage('Menghubungkan ke ' + printer.name + '...');
        await transport.connect();
        let n = 0;
        for (const id of jobIds) {
          if (run.current.cancel) break;
          while (run.current.pause && !run.current.cancel) await sleep(300);
          const job = ref.current.jobs.find((j) => j.id === id);
          const item = job && ref.current.items.find((i) => i.id === job.itemId);
          if (!job || !item || job.status === 'TERKIRIM' || job.status === 'MENCETAK') continue;
          setStatus(id, 'MENCETAK'); // kunci status sebelum kirim
          setMessage(`Mencetak ${++n}/${jobIds.length}: ${item.name} hal. ${job.page + 1}`);
          try {
            const r = await renderMono(item, job, printer, ref.current.settings);
            await transport.write(encodeJob(r, printer, job.copies));
            setStatus(id, 'TERKIRIM');
            commit((s) => ({
              ...s,
              history: [
                { id: uid(), name: item.name, page: job.page, printerName: printer.name, copies: job.copies, status: 'TERKIRIM' as const, at: Date.now() },
                ...s.history,
              ].slice(0, 500),
            }));
            if (ref.current.settings.autoDelete && printedItemIds().includes(item.id)) await deleteItems([item.id]);
            await sleep(500);
          } catch (e: any) {
            setStatus(id, 'GAGAL', String(e?.message ?? e));
            throw e; // hentikan antrean (mis. koneksi putus) agar sisanya tetap MENUNGGU
          }
        }
        setMessage(run.current.cancel ? 'Dibatalkan.' : 'Selesai dikirim ke printer.');
      } catch (e: any) {
        setMessage('Berhenti: ' + String(e?.message ?? e));
        Alert.alert('Pencetakan berhenti', String(e?.message ?? e) + '\n\nPekerjaan yang belum terkirim tetap menunggu. Periksa printer lalu coba lagi.');
      } finally {
        await transport.disconnect();
        run.current = { running: false, cancel: false, pause: false };
        setBusy(false);
        setPaused(false);
      }
    },
    [activePrinter, commit, deleteItems, printedItemIds, updatePrinter],
  );

  const pause = useCallback(() => {
    run.current.pause = !run.current.pause;
    setPaused(run.current.pause);
  }, []);
  const cancel = useCallback(() => {
    run.current.cancel = true;
  }, []);

  const testPrint = useCallback(
    async (p: PrinterProfile) => {
      if (run.current.running) return;
      run.current.running = true;
      setBusy(true);
      const t = makeTransport(p, (serviceUUID, charUUID) => updatePrinter(p.id, { serviceUUID, charUUID }));
      try {
        if (!(await ensureBtPermissions())) throw new Error('Izin Bluetooth ditolak.');
        await t.connect();
        await t.write(p.protocol === 'escpos' ? escposTestPage(p) : tsplTestPage(p));
        await sleep(800);
        Alert.alert('Terkirim', 'Halaman uji sudah dikirim. Periksa apakah label keluar dan isinya benar.');
      } catch (e: any) {
        Alert.alert('Gagal', String(e?.message ?? e));
      } finally {
        await t.disconnect();
        run.current.running = false;
        setBusy(false);
      }
    },
    [updatePrinter],
  );

  return {
    state, ready, busy, paused, message,
    importFiles, deleteItems, printedItemIds,
    setCrop, setCopies, moveJob, retryJob, splitItem,
    addPrinter, updatePrinter, removePrinter, setActivePrinter, setSettings, clearHistory,
    activePrinter, printJobs, pause, cancel, testPrint,
  };
}

export type AppApi = ReturnType<typeof useApp>;
